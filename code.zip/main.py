from modubot import Bot

def main():
    bot: Bot = Bot()
    bot.run()

if __name__ == "__main__":
    main()